import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { ENV } from '../../config/env.js';
import { db } from '../../db/connection.js';
import { AppError } from '../../utils/errors.js';
import { stripExifMetadata } from '../../utils/exif_stripper.js';

let s3Client = null;
if (ENV.AWS_ACCESS_KEY_ID && ENV.AWS_SECRET_ACCESS_KEY) {
  s3Client = new S3Client({
    region: ENV.S3_REGION,
    endpoint: ENV.S3_ENDPOINT || undefined,
    credentials: {
      accessKeyId: ENV.AWS_ACCESS_KEY_ID,
      secretAccessKey: ENV.AWS_SECRET_ACCESS_KEY
    }
  });
}

// Uploads are identified by their leading bytes, not by the filename or MIME type the client claims.
export function sniffImageType(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 12) return null;
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return { ext: 'jpg', mime: 'image/jpeg' };
  if (buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { ext: 'png', mime: 'image/png' };
  if (buffer.toString('latin1', 0, 4) === 'RIFF' && buffer.toString('latin1', 8, 12) === 'WEBP') return { ext: 'webp', mime: 'image/webp' };
  return null;
}

export class MediaStorageService {
  /**
   * Strips EXIF/GPS metadata and uploads media buffer to S3 or local storage.
   */
  static async uploadMedia({ buffer, userId = null }) {
    const type = sniffImageType(buffer);
    if (!type) {
      throw AppError.unsupportedMedia('Only JPEG, PNG or WebP images can be uploaded');
    }

    const cleanBuffer = stripExifMetadata(buffer, type.mime);
    const mediaType = type.mime;
    const hash = crypto.createHash('sha256').update(cleanBuffer).digest('hex');
    // The stored name never includes client-supplied text, so an upload can't be served back as HTML or script.
    const safeName = `${Date.now()}_${hash.substring(0, 12)}.${type.ext}`;

    if (s3Client && ENV.STORAGE_MODE === 's3') {
      const command = new PutObjectCommand({
        Bucket: ENV.S3_BUCKET,
        Key: safeName,
        Body: cleanBuffer,
        ContentType: mediaType,
        Metadata: userId ? { owner_id: String(userId) } : undefined
      });
      await s3Client.send(command);

      const getCmd = new GetObjectCommand({ Bucket: ENV.S3_BUCKET, Key: safeName });
      const signedReadUrl = await getSignedUrl(s3Client, getCmd, { expiresIn: 900 });

      return {
        url: signedReadUrl,
        key: safeName,
        sha256: hash,
        size_bytes: cleanBuffer.length,
        media_type: mediaType,
        exif_stripped: true,
        storage: 's3'
      };
    }

    // Local filesystem storage fallback
    const uploadDir = path.resolve(ENV.LOCAL_UPLOAD_DIR);
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    const filePath = path.join(uploadDir, safeName);
    fs.writeFileSync(filePath, cleanBuffer);

    return {
      url: `/uploads/${safeName}`,
      key: safeName,
      sha256: hash,
      size_bytes: cleanBuffer.length,
      media_type: mediaType,
      exif_stripped: true,
      storage: 'local'
    };
  }

  /**
   * Deletes a local upload file by key if present.
   */
  static deleteLocalMedia(key) {
    if (!key) return false;
    const safeKey = path.basename(String(key));
    const filePath = path.join(path.resolve(ENV.LOCAL_UPLOAD_DIR), safeKey);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return true;
    }
    return false;
  }

  /**
   * Generates a pre-signed S3 URL for direct client-side uploads (photo/video)
   */
  static async generatePresignedUploadUrl({ filename, mediaType = 'image/jpeg' }) {
    const safeName = `direct_${Date.now()}_${filename.replace(/[^a-zA-Z0-9._-]/g, '_')}`;

    if (s3Client && ENV.STORAGE_MODE === 's3') {
      const command = new PutObjectCommand({
        Bucket: ENV.S3_BUCKET,
        Key: safeName,
        ContentType: mediaType
      });
      const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 900 });
      return {
        upload_url: uploadUrl,
        public_url: `https://${ENV.S3_BUCKET}.s3.${ENV.S3_REGION}.amazonaws.com/${safeName}`,
        key: safeName,
        expires_in_seconds: 900
      };
    }

    // Local direct upload target for development
    return {
      upload_url: `/api/v1/vision/upload-media`,
      public_url: `/uploads/${safeName}`,
      key: safeName,
      expires_in_seconds: 900
    };
  }

  /**
   * Pre-Pickup Photo Log Manager
   * Creates an immutable, timestamped archive linked to the item before handoff/inspection.
   */
  static async createPrePickupLog({ itemId, photoUrls, operatorId, conditionNotes = '' }) {
    const timestamp = new Date().toISOString();
    const manifestPayload = JSON.stringify({
      item_id: itemId,
      timestamp,
      photo_urls: photoUrls,
      operator_id: operatorId,
      condition_notes: conditionNotes
    });

    const manifestSignature = crypto
      .createHash('sha256')
      .update(manifestPayload)
      .digest('hex');

    const archiveRecord = {
      archive_id: `ARCHIVE-${Date.now()}-${itemId.substring(0, 8)}`,
      item_id: itemId,
      timestamp,
      operator_id: operatorId,
      photo_urls: photoUrls,
      condition_notes: conditionNotes,
      immutable_hash: manifestSignature,
      verification_status: 'locked_and_archived'
    };

    const item = await db.getItem(itemId);
    if (item) {
      const currentLogs = item.metadata?.pre_pickup_logs || [];
      currentLogs.push(archiveRecord);
      await db.updateItem(itemId, {
        metadata: {
          ...item.metadata,
          pre_pickup_logs: currentLogs
        }
      });
    }

    return archiveRecord;
  }
}
